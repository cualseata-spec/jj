#include "PluginEditor.h"

//==============================================================================
EQEditor::EQEditor (EQProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);
    levels.fill (-120.0f);

    for (auto* s : { &freqSlider, &gainSlider, &qSlider })
    {
        s->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s->setTextBoxStyle (juce::Slider::TextBoxBelow, false, 100, 18);
        addAndMakeVisible (*s);
    }

    freqSlider.textFromValueFunction = [] (double v) { return fmtFreq ((float) v); };
    freqSlider.valueFromTextFunction = [] (const juce::String& t)
    {
        const double v = t.getDoubleValue();
        return t.containsIgnoreCase ("k") ? v * 1000.0 : v;
    };
    gainSlider.textFromValueFunction = [] (double v) { return juce::String (v > 0.0 ? "+" : "") + juce::String (v, 1) + " dB"; };
    qSlider.textFromValueFunction    = [] (double v) { return juce::String (v, 2); };

    outSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    outSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 70, 18);
    outSlider.setTextValueSuffix (" dB");
    addAndMakeVisible (outSlider);
    outAtt = std::make_unique<SA> (proc.apvts, "out_gain", outSlider);

    addAndMakeVisible (analyzerBtn);
    analyzerAtt = std::make_unique<BA> (proc.apvts, "analyzer", analyzerBtn);

    addAndMakeVisible (bandOnBtn);

    rangeBox.addItem ("Range 6 dB", 1);
    rangeBox.addItem ("Range 12 dB", 2);
    rangeBox.addItem ("Range 18 dB", 3);
    rangeBox.addItem ("Range 30 dB", 4);
    rangeBox.setSelectedId (2, juce::dontSendNotification);
    rangeBox.onChange = [this]
    {
        const float ranges[] = { 6.0f, 12.0f, 18.0f, 30.0f };
        rangeDb = ranges[juce::jlimit (0, 3, rangeBox.getSelectedId() - 1)];
        repaint();
    };
    addAndMakeVisible (rangeBox);

    typeBox.addItemList (eq::typeNames(), 1);
    addAndMakeVisible (typeBox);

    selectBand (0);

    setSize (940, 580);
    setResizable (true, true);
    setResizeLimits (720, 460, 1800, 1100);
    startTimerHz (30);
}

EQEditor::~EQEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

//==============================================================================
float EQEditor::getP (int band, const char* name) const
{
    return proc.apvts.getRawParameterValue (eq::pid (band, name))->load();
}

void EQEditor::setParam (const juce::String& id, float value, bool withGesture)
{
    if (auto* p = proc.apvts.getParameter (id))
    {
        if (withGesture) p->beginChangeGesture();
        p->setValueNotifyingHost (p->convertTo0to1 (value));
        if (withGesture) p->endChangeGesture();
    }
}

void EQEditor::gesture (int band, bool begin)
{
    for (auto* n : { "freq", "gain" })
        if (auto* p = proc.apvts.getParameter (eq::pid (band, n)))
        {
            if (begin) p->beginChangeGesture();
            else       p->endChangeGesture();
        }
}

double EQEditor::getSR() const
{
    const double sr = proc.getSampleRate();
    return sr > 0.0 ? sr : 44100.0;
}

EQEditor::CoefPtr EQEditor::coeffsFor (int b) const
{
    if (! isOn (b))
        return nullptr;
    return eq::makeCoefficients ((int) getP (b, "type"), getSR(), getP (b, "freq"), getP (b, "gain"), getP (b, "q"));
}

juce::Point<float> EQEditor::nodePos (int b) const
{
    const int type = (int) getP (b, "type");
    const float gdb = eq::typeUsesGain (type) ? getP (b, "gain") : 0.0f;
    return { juce::jlimit (graph.getX(), graph.getRight(), freqToX (getP (b, "freq"))),
             juce::jlimit (graph.getY() + 2.0f, graph.getBottom() - 2.0f, gainToY (gdb)) };
}

int EQEditor::hitTest (juce::Point<float> p) const
{
    int best = -1;
    float bestD = 14.0f;
    for (int b = 0; b < eq::numBands; ++b)
    {
        if (! isOn (b)) continue;
        const float d = nodePos (b).getDistanceFrom (p);
        if (d <= bestD) { bestD = d; best = b; }
    }
    return best;
}

void EQEditor::selectBand (int b)
{
    freqAtt.reset(); gainAtt.reset(); qAtt.reset(); typeAtt.reset(); onAtt.reset();
    selected = b;

    freqAtt = std::make_unique<SA> (proc.apvts, eq::pid (b, "freq"), freqSlider);
    gainAtt = std::make_unique<SA> (proc.apvts, eq::pid (b, "gain"), gainSlider);
    qAtt    = std::make_unique<SA> (proc.apvts, eq::pid (b, "q"),    qSlider);
    typeAtt = std::make_unique<CA> (proc.apvts, eq::pid (b, "type"), typeBox);
    onAtt   = std::make_unique<BA> (proc.apvts, eq::pid (b, "on"),   bandOnBtn);

    const auto col = bandColour (b);
    for (auto* s : { &freqSlider, &gainSlider, &qSlider })
        s->setColour (juce::Slider::rotarySliderFillColourId, col);

    bandOnBtn.setButtonText ("Band " + juce::String (b + 1) + " On");
    repaint();
}

void EQEditor::showTypeMenu (int b)
{
    juce::PopupMenu m;
    const int cur = (int) getP (b, "type");
    const auto names = eq::typeNames();
    for (int t = 0; t < names.size(); ++t)
        m.addItem (t + 1, names[t], true, t == cur);
    m.addSeparator();
    m.addItem (100, "Delete band");

    juce::Component::SafePointer<EQEditor> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options(), [safe, b] (int r)
    {
        if (safe == nullptr) return;
        if (r >= 1 && r <= eq::typeNames().size()) safe->setParam (eq::pid (b, "type"), (float) (r - 1));
        else if (r == 100)                          safe->setParam (eq::pid (b, "on"), 0.0f);
    });
}

//==============================================================================
void EQEditor::resized()
{
    auto r = getLocalBounds();

    auto top = r.removeFromTop (40).reduced (10, 6);
    outSlider.setBounds (top.removeFromRight (200));
    outLabel = top.removeFromRight (36);
    top.removeFromRight (10);
    rangeBox.setBounds (top.removeFromRight (120));
    top.removeFromRight (8);
    analyzerBtn.setBounds (top.removeFromRight (90));

    bottomPanel = r.removeFromBottom (124).reduced (10, 4);
    graph = r.reduced (10, 4).toFloat();

    auto bp = bottomPanel.reduced (10, 8);
    auto left = bp.removeFromLeft (170);
    bandOnBtn.setBounds (left.removeFromTop (30));
    left.removeFromTop (10);
    typeBox.setBounds (left.removeFromTop (28));

    auto knobs = bp;
    auto labelRow = knobs.removeFromTop (16);
    const int kw = juce::jmin (160, knobs.getWidth() / 3);
    freqSlider.setBounds (knobs.removeFromLeft (kw));
    gainSlider.setBounds (knobs.removeFromLeft (kw));
    qSlider.setBounds (knobs.removeFromLeft (kw));
    for (auto& l : knobLabels)
        l = labelRow.removeFromLeft (kw);
}

//==============================================================================
void EQEditor::timerCallback()
{
    updateSpectrum();
    gainSlider.setEnabled (eq::typeUsesGain ((int) getP (selected, "type")));
    repaint (graph.expanded (2.0f).toNearestInt());
}

void EQEditor::updateSpectrum()
{
    if (proc.apvts.getRawParameterValue ("analyzer")->load() < 0.5f)
        return;

    constexpr int mask = EQProcessor::ringSize - 1;
    const int w = proc.ringWrite.load (std::memory_order_acquire);

    for (int i = 0; i < fftSize; ++i)
        fftData[(size_t) i] = proc.ring[(size_t) ((w - fftSize + i + EQProcessor::ringSize) & mask)];
    std::fill (fftData.begin() + fftSize, fftData.end(), 0.0f);

    window.multiplyWithWindowingTable (fftData.data(), (size_t) fftSize);
    fft.performFrequencyOnlyForwardTransform (fftData.data());

    const float binHz = (float) getSR() / (float) fftSize;
    for (int i = 1; i < fftSize / 2; ++i)
    {
        float db = juce::Decibels::gainToDecibels (fftData[(size_t) i] / ((float) fftSize * 0.25f), -120.0f);
        db += 4.5f * std::log2 ((float) i * binHz / 1000.0f);   // inclinacion de 4.5 dB/oct (como un analizador "pink")
        float& l = levels[(size_t) i];
        l = db > l ? l * 0.3f + db * 0.7f : l * 0.9f + db * 0.1f;
    }
}

//==============================================================================
void EQEditor::paint (juce::Graphics& g)
{
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff23262c), 0.0f, 0.0f,
                                             juce::Colour (0xff141619), 0.0f, (float) getHeight(), false));
    g.fillAll();

    // Cabecera
    g.setColour (juce::Colour (0xffe8ebf0));
    g.setFont (20.0f);
    g.drawText ("ProEQ", 14, 6, 90, 28, juce::Justification::centredLeft, false);
    const int hintW = analyzerBtn.getX() - 120;
    if (hintW > 120)
    {
        g.setColour (juce::Colour (0xff7d838f));
        g.setFont (12.0f);
        g.drawText ("Double-click: add/remove band  -  Wheel: Q  -  Right-click: type",
                    110, 6, hintW, 28, juce::Justification::centredLeft, true);
    }
    g.setColour (juce::Colour (0xff9aa0ac));
    g.setFont (12.0f);
    g.drawText ("OUT", outLabel, juce::Justification::centredRight, false);

    // Grafico
    g.setColour (juce::Colour (0xff0d0e11));
    g.fillRoundedRectangle (graph, 6.0f);
    {
        juce::Graphics::ScopedSaveState ss (g);
        g.reduceClipRegion (graph.toNearestInt());
        drawGrid (g);
        drawSpectrum (g);
        drawCurve (g);
        drawNodes (g);
    }
    g.setColour (juce::Colour (0xff3a3e48));
    g.drawRoundedRectangle (graph, 6.0f, 1.0f);

    // Panel inferior
    g.setColour (juce::Colour (0xff1a1c21));
    g.fillRoundedRectangle (bottomPanel.toFloat(), 6.0f);
    g.setColour (juce::Colour (0xff2e323a));
    g.drawRoundedRectangle (bottomPanel.toFloat(), 6.0f, 1.0f);
    g.setColour (juce::Colour (0xff9aa0ac));
    g.setFont (12.0f);
    const char* names[] = { "FREQ", "GAIN", "Q" };
    for (size_t i = 0; i < 3; ++i)
        g.drawText (names[i], knobLabels[i], juce::Justification::centred, false);
}

void EQEditor::drawGrid (juce::Graphics& g)
{
    const float fs[] = { 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 600, 700, 800, 900,
                         1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 20000 };
    for (float f : fs)
    {
        const bool major = (f == 100.0f || f == 1000.0f || f == 10000.0f);
        g.setColour (juce::Colours::white.withAlpha (major ? 0.10f : 0.045f));
        g.drawVerticalLine ((int) freqToX (f), graph.getY(), graph.getBottom());
    }

    struct L { float f; const char* t; };
    const L labels[] = { { 50, "50" }, { 100, "100" }, { 200, "200" }, { 500, "500" }, { 1000, "1k" },
                         { 2000, "2k" }, { 5000, "5k" }, { 10000, "10k" } };
    g.setFont (11.0f);
    g.setColour (juce::Colours::white.withAlpha (0.35f));
    for (auto& l : labels)
        g.drawText (l.t, juce::Rectangle<float> (freqToX (l.f) - 20.0f, graph.getBottom() - 16.0f, 40.0f, 14.0f),
                    juce::Justification::centred, false);

    const float step = rangeDb <= 6.0f ? 2.0f : rangeDb <= 12.0f ? 3.0f : rangeDb <= 18.0f ? 6.0f : 10.0f;
    const int kMax = (int) (rangeDb / step);
    for (int k = -kMax; k <= kMax; ++k)
    {
        const float db = (float) k * step;
        const float y = gainToY (db);
        g.setColour (juce::Colours::white.withAlpha (k == 0 ? 0.22f : 0.07f));
        g.drawHorizontalLine ((int) y, graph.getX(), graph.getRight());
        g.setColour (juce::Colours::white.withAlpha (0.35f));
        g.drawText (juce::String (db > 0.0f ? "+" : "") + juce::String ((int) db),
                    juce::Rectangle<float> (graph.getRight() - 36.0f, y - 6.0f, 30.0f, 12.0f),
                    juce::Justification::centredRight, false);
    }
}

void EQEditor::drawSpectrum (juce::Graphics& g)
{
    if (proc.apvts.getRawParameterValue ("analyzer")->load() < 0.5f)
        return;

    const float binHz = (float) getSR() / (float) fftSize;
    const int maxBin = fftSize / 2 - 1;
    auto dbToY = [this] (float db)
    {
        return juce::jmap (juce::jlimit (specMinDb, specMaxDb, db), specMinDb, specMaxDb, graph.getBottom(), graph.getY());
    };

    juce::Path line, area;
    area.startNewSubPath (graph.getX(), graph.getBottom());
    bool first = true;

    for (float x = graph.getX(); x <= graph.getRight() + 0.5f; x += 2.0f)
    {
        const float f0 = xToFreq (x), f1 = xToFreq (x + 2.0f);
        float db;

        if (f1 - f0 < binHz)
        {
            const float pos = f0 / binHz;
            const int i0 = juce::jlimit (1, maxBin - 1, (int) std::floor (pos));
            const float fr = juce::jlimit (0.0f, 1.0f, pos - (float) i0);
            db = levels[(size_t) i0] * (1.0f - fr) + levels[(size_t) i0 + 1] * fr;
        }
        else
        {
            const int b0 = juce::jlimit (1, maxBin, (int) std::floor (f0 / binHz));
            const int b1 = juce::jlimit (b0, maxBin, (int) std::ceil (f1 / binHz));
            db = -200.0f;
            for (int i = b0; i <= b1; ++i)
                db = std::max (db, levels[(size_t) i]);
        }

        const float y = dbToY (db);
        if (first) { line.startNewSubPath (x, y); first = false; }
        else         line.lineTo (x, y);
        area.lineTo (x, y);
    }
    area.lineTo (graph.getRight(), graph.getBottom());
    area.closeSubPath();

    const auto c = juce::Colour (0xff5aa0e6);
    g.setGradientFill (juce::ColourGradient (c.withAlpha (0.50f), 0.0f, graph.getY(),
                                             c.withAlpha (0.04f), 0.0f, graph.getBottom(), false));
    g.fillPath (area);
    g.setColour (c.withAlpha (0.75f));
    g.strokePath (line, juce::PathStrokeType (1.0f));
}

void EQEditor::drawCurve (juce::Graphics& g)
{
    const double sr = getSR();
    std::array<CoefPtr, (size_t) eq::numBands> co;
    for (int b = 0; b < eq::numBands; ++b)
        co[(size_t) b] = coeffsFor (b);

    const float y0 = gainToY (0.0f);

    auto bandDb = [&] (int b, float f)
    {
        return juce::Decibels::gainToDecibels ((float) co[(size_t) b]->getMagnitudeForFrequency ((double) f, sr), -100.0f);
    };

    auto build = [&] (juce::Path& line, juce::Path& area, const std::function<float (float)>& dbAt)
    {
        bool first = true;
        area.startNewSubPath (graph.getX(), y0);
        for (float x = graph.getX(); x <= graph.getRight() + 0.5f; x += 2.0f)
        {
            const float y = gainToY (dbAt (xToFreq (x)));
            if (first) { line.startNewSubPath (x, y); first = false; }
            else         line.lineTo (x, y);
            area.lineTo (x, y);
        }
        area.lineTo (graph.getRight(), y0);
        area.closeSubPath();
    };

    // Curva de la banda seleccionada
    if (co[(size_t) selected] != nullptr)
    {
        juce::Path l, a;
        build (l, a, [&] (float f) { return bandDb (selected, f); });
        g.setColour (bandColour (selected).withAlpha (0.22f));
        g.fillPath (a);
    }

    // Curva total
    juce::Path line, area;
    build (line, area, [&] (float f)
    {
        float s = 0.0f;
        for (int b = 0; b < eq::numBands; ++b)
            if (co[(size_t) b] != nullptr)
                s += bandDb (b, f);
        return s;
    });

    const auto yellow = juce::Colour (0xffffc247);
    g.setColour (yellow.withAlpha (0.07f));
    g.fillPath (area);
    g.setColour (yellow.withAlpha (0.18f));
    g.strokePath (line, juce::PathStrokeType (6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (yellow);
    g.strokePath (line, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void EQEditor::drawNodes (juce::Graphics& g)
{
    for (int pass = 0; pass < 2; ++pass)
    {
        for (int b = 0; b < eq::numBands; ++b)
        {
            if (! isOn (b) || ((b == selected) != (pass == 1)))
                continue;

            const auto c = bandColour (b);
            const auto pos = nodePos (b);
            const bool sel = (b == selected);
            const bool hot = (b == hover) || (b == dragBand);
            const float r = hot ? 10.0f : 8.0f;

            if (sel)
            {
                g.setColour (c.withAlpha (0.25f));
                g.fillEllipse (pos.x - r - 5.0f, pos.y - r - 5.0f, (r + 5.0f) * 2.0f, (r + 5.0f) * 2.0f);
            }
            g.setColour (c);
            g.fillEllipse (pos.x - r, pos.y - r, r * 2.0f, r * 2.0f);
            g.setColour (sel ? juce::Colours::white : juce::Colours::black.withAlpha (0.5f));
            g.drawEllipse (pos.x - r, pos.y - r, r * 2.0f, r * 2.0f, 1.5f);
            g.setColour (juce::Colour (0xff101114));
            g.setFont (10.0f);
            g.drawText (juce::String (b + 1), juce::Rectangle<float> (pos.x - r, pos.y - r, r * 2.0f, r * 2.0f),
                        juce::Justification::centred, false);
        }
    }

    // Tooltip con los valores
    const int tb = dragBand >= 0 ? dragBand : hover;
    if (tb >= 0 && isOn (tb))
    {
        const auto pos = nodePos (tb);
        const int type = (int) getP (tb, "type");
        juce::String txt = fmtFreq (getP (tb, "freq"));
        if (eq::typeUsesGain (type))
            txt += "   " + juce::String (getP (tb, "gain") >= 0.0f ? "+" : "") + juce::String (getP (tb, "gain"), 1) + " dB";
        txt += "   Q " + juce::String (getP (tb, "q"), 2);

        juce::Rectangle<float> box (pos.x - 95.0f, pos.y - 42.0f, 190.0f, 22.0f);
        if (box.getY() < graph.getY() + 4.0f)
            box.setY (pos.y + 16.0f);
        box = box.constrainedWithin (graph.reduced (4.0f));

        g.setColour (juce::Colour (0xee15171b));
        g.fillRoundedRectangle (box, 5.0f);
        g.setColour (bandColour (tb).withAlpha (0.8f));
        g.drawRoundedRectangle (box, 5.0f, 1.0f);
        g.setColour (juce::Colour (0xffe8ebf0));
        g.setFont (12.0f);
        g.drawText (txt, box, juce::Justification::centred, false);
    }
}

//==============================================================================
void EQEditor::mouseMove (const juce::MouseEvent& e)
{
    hover = graph.contains (e.position) ? hitTest (e.position) : -1;
}

void EQEditor::mouseExit (const juce::MouseEvent&) { hover = -1; }

void EQEditor::mouseDown (const juce::MouseEvent& e)
{
    if (! graph.contains (e.position))
        return;

    if (dragBand >= 0) { gesture (dragBand, false); dragBand = -1; }

    const int hit = hitTest (e.position);
    if (hit < 0)
        return;

    if (hit != selected)
        selectBand (hit);

    if (e.mods.isPopupMenu())
    {
        showTypeMenu (hit);
        return;
    }

    dragBand = hit;
    gesture (hit, true);
}

void EQEditor::mouseDrag (const juce::MouseEvent& e)
{
    if (dragBand < 0)
        return;

    const float x = juce::jlimit (graph.getX(), graph.getRight(), e.position.x);
    const float y = juce::jlimit (graph.getY(), graph.getBottom(), e.position.y);

    setParam (eq::pid (dragBand, "freq"), xToFreq (x), false);
    if (eq::typeUsesGain ((int) getP (dragBand, "type")))
        setParam (eq::pid (dragBand, "gain"), yToGain (y), false);
}

void EQEditor::mouseUp (const juce::MouseEvent&)
{
    if (dragBand >= 0)
    {
        gesture (dragBand, false);
        dragBand = -1;
    }
}

void EQEditor::mouseDoubleClick (const juce::MouseEvent& e)
{
    if (! graph.contains (e.position))
        return;

    const int hit = hitTest (e.position);
    if (hit >= 0)
    {
        setParam (eq::pid (hit, "on"), 0.0f);
        hover = -1;
        return;
    }

    for (int b = 0; b < eq::numBands; ++b)
    {
        if (isOn (b))
            continue;

        setParam (eq::pid (b, "type"), 0.0f);
        setParam (eq::pid (b, "freq"), xToFreq (e.position.x));
        setParam (eq::pid (b, "gain"), yToGain (e.position.y));
        setParam (eq::pid (b, "q"), 1.0f);
        setParam (eq::pid (b, "on"), 1.0f);
        selectBand (b);
        break;
    }
}

void EQEditor::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel)
{
    const int hit = graph.contains (e.position) ? hitTest (e.position) : -1;
    if (hit < 0)
        return;

    const float q = getP (hit, "q");
    setParam (eq::pid (hit, "q"), q * std::exp (wheel.deltaY * 2.0f));
}
