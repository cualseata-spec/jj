#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout EQProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout layout;

    const float defFreq[eq::numBands] = { 80.0f, 400.0f, 2000.0f, 10000.0f, 150.0f, 1000.0f, 5000.0f, 15000.0f };
    const int   defType[eq::numBands] = { 1, 0, 0, 2, 0, 0, 0, 0 };

    for (int i = 0; i < eq::numBands; ++i)
    {
        const String n = "Band " + String (i + 1) + " ";

        NormalisableRange<float> freqRange (20.0f, 20000.0f, 0.01f);
        freqRange.setSkewForCentre (1000.0f);
        NormalisableRange<float> qRange (0.1f, 18.0f, 0.01f);
        qRange.setSkewForCentre (1.0f);

        layout.add (std::make_unique<AudioParameterBool>   (ParameterID { eq::pid (i, "on"), 1 },   n + "On", i < 4));
        layout.add (std::make_unique<AudioParameterChoice> (ParameterID { eq::pid (i, "type"), 1 }, n + "Type", eq::typeNames(), defType[i]));
        layout.add (std::make_unique<AudioParameterFloat>  (ParameterID { eq::pid (i, "freq"), 1 }, n + "Freq", freqRange, defFreq[i]));
        layout.add (std::make_unique<AudioParameterFloat>  (ParameterID { eq::pid (i, "gain"), 1 }, n + "Gain",
                                                            NormalisableRange<float> (-24.0f, 24.0f, 0.01f), 0.0f));
        layout.add (std::make_unique<AudioParameterFloat>  (ParameterID { eq::pid (i, "q"), 1 },    n + "Q", qRange, 1.0f));
    }

    layout.add (std::make_unique<AudioParameterFloat> (ParameterID { "out_gain", 1 }, "Output Gain",
                                                       NormalisableRange<float> (-24.0f, 24.0f, 0.01f), 0.0f));
    layout.add (std::make_unique<AudioParameterBool> (ParameterID { "analyzer", 1 }, "Analyzer", true));
    return layout;
}

EQProcessor::EQProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    for (int i = 0; i < eq::numBands; ++i)
        bandParams[(size_t) i] = { apvts.getRawParameterValue (eq::pid (i, "on")),
                                   apvts.getRawParameterValue (eq::pid (i, "type")),
                                   apvts.getRawParameterValue (eq::pid (i, "freq")),
                                   apvts.getRawParameterValue (eq::pid (i, "gain")),
                                   apvts.getRawParameterValue (eq::pid (i, "q")) };
    outGain = apvts.getRawParameterValue ("out_gain");
}

void EQProcessor::prepareToPlay (double, int)
{
    for (auto& ch : filters)
        for (auto& f : ch)
            f.reset();

    for (auto& c : cache)
        c = BandCache {};

    lastOutGain = juce::Decibels::decibelsToGain (outGain->load());
}

bool EQProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return layouts.getMainInputChannelSet() == out;
}

void EQProcessor::updateFilters()
{
    const double sr = getSampleRate();

    for (int b = 0; b < eq::numBands; ++b)
    {
        auto& p = bandParams[(size_t) b];
        auto& c = cache[(size_t) b];

        const bool  on   = p.on->load() > 0.5f;
        const int   type = (int) p.type->load();
        const float f = p.freq->load(), g = p.gain->load(), q = p.q->load();

        if (on && (! c.on || type != c.type || f != c.freq || g != c.gain || q != c.q))
        {
            auto coeffs = eq::makeCoefficients (type, sr, f, g, q);
            for (auto& ch : filters)
            {
                if (! c.on)
                    ch[(size_t) b].reset();
                ch[(size_t) b].coefficients = coeffs;
            }
        }

        c.on = on; c.type = type; c.freq = f; c.gain = g; c.q = q;
    }
}

void EQProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int n = buffer.getNumSamples();
    const int numCh = juce::jmin (buffer.getNumChannels(), 2);

    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, n);

    updateFilters();

    for (int ch = 0; ch < numCh; ++ch)
    {
        float* data = buffer.getWritePointer (ch);

        for (int b = 0; b < eq::numBands; ++b)
        {
            if (! cache[(size_t) b].on)
                continue;

            auto& filt = filters[(size_t) ch][(size_t) b];
            for (int i = 0; i < n; ++i)
                data[i] = filt.processSample (data[i]);
        }
    }

    const float g = juce::Decibels::decibelsToGain (outGain->load());
    buffer.applyGainRamp (0, n, lastOutGain, g);
    lastOutGain = g;

    // Alimentar el analizador (mono)
    constexpr int mask = ringSize - 1;
    int w = ringWrite.load (std::memory_order_relaxed);
    const float* l = buffer.getReadPointer (0);
    const float* r = numCh > 1 ? buffer.getReadPointer (1) : nullptr;
    for (int i = 0; i < n; ++i)
    {
        ring[(size_t) ((w + i) & mask)] = r != nullptr ? 0.5f * (l[i] + r[i]) : l[i];
    }
    ringWrite.store ((w + n) & mask, std::memory_order_release);
}

juce::AudioProcessorEditor* EQProcessor::createEditor() { return new EQEditor (*this); }

void EQProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void EQProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new EQProcessor(); }
