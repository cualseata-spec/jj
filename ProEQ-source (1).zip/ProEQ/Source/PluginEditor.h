#pragma once
#include "PluginProcessor.h"

//==============================================================================
class FFLookAndFeel : public juce::LookAndFeel_V4
{
public:
    FFLookAndFeel()
    {
        setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff23262c));
        setColour (juce::ComboBox::outlineColourId,    juce::Colour (0xff3a3e48));
        setColour (juce::ComboBox::textColourId,       juce::Colour (0xffd8dce4));
        setColour (juce::ComboBox::arrowColourId,      juce::Colour (0xff9aa0ac));
        setColour (juce::PopupMenu::backgroundColourId,            juce::Colour (0xff1e2025));
        setColour (juce::PopupMenu::textColourId,                  juce::Colour (0xffd8dce4));
        setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xff3b4a63));
        setColour (juce::PopupMenu::highlightedTextColourId,       juce::Colours::white);
        setColour (juce::Slider::textBoxTextColourId,       juce::Colour (0xffd8dce4));
        setColour (juce::Slider::textBoxOutlineColourId,    juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::trackColourId,      juce::Colour (0xffffc247));
        setColour (juce::Slider::backgroundColourId, juce::Colour (0xff30343c));
        setColour (juce::Slider::thumbColourId,      juce::Colour (0xffe8ebf0));
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                           float a0, float a1, juce::Slider& s) override
    {
        auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (6.0f);
        const float radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
        const auto c = bounds.getCentre();
        const float alpha = s.isEnabled() ? 1.0f : 0.3f;
        const float arcW = 4.0f;
        const float arcR = radius - arcW * 0.5f;
        const float ang = a0 + pos * (a1 - a0);
        const auto fill = s.findColour (juce::Slider::rotarySliderFillColourId).withAlpha (alpha);

        juce::Path track;
        track.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0, a1, true);
        g.setColour (juce::Colour (0xff30343c).withAlpha (alpha));
        g.strokePath (track, juce::PathStrokeType (arcW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        juce::Path val;
        val.addCentredArc (c.x, c.y, arcR, arcR, 0.0f, a0, ang, true);
        g.setColour (fill);
        g.strokePath (val, juce::PathStrokeType (arcW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        const float kr = radius - arcW - 4.0f;
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff3d414b).withAlpha (alpha), c.x, c.y - kr,
                                                 juce::Colour (0xff1c1e23).withAlpha (alpha), c.x, c.y + kr, false));
        g.fillEllipse (c.x - kr, c.y - kr, kr * 2.0f, kr * 2.0f);

        juce::Path ptr;
        ptr.addRoundedRectangle (-1.5f, -kr, 3.0f, kr * 0.55f, 1.5f);
        g.setColour (fill);
        g.fillPath (ptr, juce::AffineTransform::rotation (ang).translated (c.x, c.y));
    }

    void drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool highlighted, bool) override
    {
        auto r = b.getLocalBounds().toFloat().reduced (1.0f);
        const bool on = b.getToggleState();
        g.setColour (on ? juce::Colour (0xffffc247) : juce::Colour (0xff2a2d34));
        g.fillRoundedRectangle (r, 5.0f);
        g.setColour (highlighted ? juce::Colours::white.withAlpha (0.5f) : juce::Colour (0xff4a4e58));
        g.drawRoundedRectangle (r, 5.0f, 1.0f);
        g.setColour (on ? juce::Colour (0xff1a1a1a) : juce::Colour (0xffc8ccd4));
        g.setFont (13.0f);
        g.drawText (b.getButtonText(), r, juce::Justification::centred, false);
    }
};

//==============================================================================
class EQEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit EQEditor (EQProcessor&);
    ~EQEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    void mouseMove (const juce::MouseEvent&) override;
    void mouseExit (const juce::MouseEvent&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

private:
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using CoefPtr = juce::dsp::IIR::Coefficients<float>::Ptr;

    void timerCallback() override;
    void updateSpectrum();
    void selectBand (int b);
    void showTypeMenu (int b);

    void drawGrid (juce::Graphics&);
    void drawSpectrum (juce::Graphics&);
    void drawCurve (juce::Graphics&);
    void drawNodes (juce::Graphics&);

    float getP (int band, const char* name) const;
    bool  isOn (int band) const { return getP (band, "on") > 0.5f; }
    void  setParam (const juce::String& id, float value, bool withGesture = true);
    void  gesture (int band, bool begin);
    CoefPtr coeffsFor (int band) const;
    double getSR() const;
    int  hitTest (juce::Point<float> p) const;
    juce::Point<float> nodePos (int band) const;

    float freqToX (float f) const { return graph.getX() + graph.getWidth() * (std::log (f / 20.0f) / std::log (1000.0f)); }
    float xToFreq (float x) const { return 20.0f * std::pow (1000.0f, (x - graph.getX()) / graph.getWidth()); }
    float gainToY (float g) const { return juce::jmap (g, -rangeDb, rangeDb, graph.getBottom(), graph.getY()); }
    float yToGain (float y) const { return juce::jmap (y, graph.getBottom(), graph.getY(), -rangeDb, rangeDb); }

    static juce::Colour bandColour (int b) { return juce::Colour::fromHSV (std::fmod (0.08f + (float) b * 0.125f, 1.0f), 0.65f, 1.0f, 1.0f); }
    static juce::String fmtFreq (float f) { return f >= 1000.0f ? juce::String (f / 1000.0f, 2) + " kHz" : juce::String (f, 1) + " Hz"; }

    EQProcessor& proc;
    FFLookAndFeel lnf;

    juce::Rectangle<float> graph;
    juce::Rectangle<int> bottomPanel, outLabel;
    std::array<juce::Rectangle<int>, 3> knobLabels;

    int selected = 0, hover = -1, dragBand = -1;
    float rangeDb = 12.0f;

    juce::ToggleButton analyzerBtn { "Analyzer" }, bandOnBtn { "Band On" };
    juce::ComboBox rangeBox, typeBox;
    juce::Slider freqSlider, gainSlider, qSlider, outSlider;
    std::unique_ptr<SA> outAtt, freqAtt, gainAtt, qAtt;
    std::unique_ptr<BA> analyzerAtt, onAtt;
    std::unique_ptr<CA> typeAtt;

    // Analizador
    static constexpr int fftOrder = 12;
    static constexpr int fftSize = 1 << fftOrder;
    static constexpr float specMinDb = -80.0f, specMaxDb = 10.0f;
    juce::dsp::FFT fft { fftOrder };
    juce::dsp::WindowingFunction<float> window { (size_t) fftSize, juce::dsp::WindowingFunction<float>::hann };
    std::array<float, (size_t) fftSize * 2> fftData {};
    std::array<float, (size_t) fftSize / 2> levels {};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (EQEditor)
};
