#pragma once
#include "Common.h"

class EQProcessor : public juce::AudioProcessor
{
public:
    EQProcessor();
    ~EQProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "ProEQ"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

    // Buffer circular (mono, post-EQ) que lee el editor para el analizador de espectro
    static constexpr int ringSize = 1 << 14;
    std::array<float, ringSize> ring {};
    std::atomic<int> ringWrite { 0 };

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void updateFilters();

    struct BandParams { std::atomic<float>* on; std::atomic<float>* type; std::atomic<float>* freq;
                        std::atomic<float>* gain; std::atomic<float>* q; };
    struct BandCache  { bool on = false; int type = -1; float freq = -1.0f, gain = -999.0f, q = -1.0f; };

    std::array<BandParams, eq::numBands> bandParams {};
    std::array<BandCache, eq::numBands> cache {};
    std::array<std::array<juce::dsp::IIR::Filter<float>, eq::numBands>, 2> filters;

    std::atomic<float>* outGain = nullptr;
    float lastOutGain = 1.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (EQProcessor)
};
