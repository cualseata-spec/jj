#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>

namespace eq
{
    constexpr int numBands = 8;

    inline juce::StringArray typeNames()
    {
        return { "Bell", "Low Shelf", "High Shelf", "Low Cut", "High Cut", "Notch" };
    }

    // band: 0..7  ->  "b1_freq", "b2_gain", ...
    inline juce::String pid (int band, const juce::String& name)
    {
        return "b" + juce::String (band + 1) + "_" + name;
    }

    inline bool typeUsesGain (int type) { return type <= 2; }

    inline juce::dsp::IIR::Coefficients<float>::Ptr makeCoefficients (int type, double sr,
                                                                      float freq, float gainDb, float q)
    {
        using C = juce::dsp::IIR::Coefficients<float>;
        freq = juce::jlimit (10.0f, (float) sr * 0.49f, freq);
        q = juce::jmax (0.05f, q);
        const float g = juce::Decibels::decibelsToGain (gainDb);

        switch (type)
        {
            case 0:  return C::makePeakFilter (sr, freq, q, g);
            case 1:  return C::makeLowShelf   (sr, freq, q, g);
            case 2:  return C::makeHighShelf  (sr, freq, q, g);
            case 3:  return C::makeHighPass   (sr, freq, q);
            case 4:  return C::makeLowPass    (sr, freq, q);
            default: return C::makeNotch      (sr, freq, q);
        }
    }
}
