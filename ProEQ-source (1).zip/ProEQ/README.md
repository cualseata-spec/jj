# ProEQ – ecualizador paramétrico estilo FabFilter (VST3)

8 bandas · Bell / Low Shelf / High Shelf / Low Cut / High Cut / Notch · analizador de espectro en tiempo real · nodos arrastrables.

## Manejo
- **Doble clic** en un espacio vacío → añade una banda · **doble clic** en un nodo → la elimina
- **Arrastrar** nodo → frecuencia / ganancia
- **Rueda** sobre un nodo → Q
- **Clic derecho** en un nodo → cambiar tipo de filtro
- Knobs inferiores → ajuste fino con valores numéricos

## Opción A (sin instalar nada): compilar en GitHub
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestaña **Actions** → espera a que termine "Build ProEQ".
3. Descarga el artefacto `ProEQ-windows-latest` → dentro está `VST3/ProEQ.vst3`.

## Opción B: compilar en tu PC (Windows)
Requisitos: Visual Studio 2022 (carga de trabajo "Desarrollo para el escritorio con C++") y CMake.

```
cd ProEQ
cmake -B build -G "Visual Studio 17 2022"
cmake --build build --config Release
```
Resultado: `build\ProEQ_artefacts\Release\VST3\ProEQ.vst3`
(en Windows el `.vst3` es una DLL; el binario real está en `ProEQ.vst3\Contents\x86_64-win\ProEQ.vst3`).
También se genera `Standalone\ProEQ.exe` para probarlo sin DAW.

## Instalar
Copia la carpeta `ProEQ.vst3` a `C:\Program Files\Common Files\VST3\` y reescanea plugins en tu DAW.
